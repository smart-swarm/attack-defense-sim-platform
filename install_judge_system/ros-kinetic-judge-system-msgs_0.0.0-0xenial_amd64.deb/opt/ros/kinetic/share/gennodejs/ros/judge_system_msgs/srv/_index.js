
"use strict";

let clear_bullets = require('./clear_bullets.js')

module.exports = {
  clear_bullets: clear_bullets,
};
