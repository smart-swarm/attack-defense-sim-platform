// Auto-generated. Do not edit!

// (in-package judge_system_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class Alive_model {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.name = null;
      this.blood = null;
      this.bullet = null;
    }
    else {
      if (initObj.hasOwnProperty('name')) {
        this.name = initObj.name
      }
      else {
        this.name = new std_msgs.msg.String();
      }
      if (initObj.hasOwnProperty('blood')) {
        this.blood = initObj.blood
      }
      else {
        this.blood = new std_msgs.msg.Float64();
      }
      if (initObj.hasOwnProperty('bullet')) {
        this.bullet = initObj.bullet
      }
      else {
        this.bullet = new std_msgs.msg.Int32();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Alive_model
    // Serialize message field [name]
    bufferOffset = std_msgs.msg.String.serialize(obj.name, buffer, bufferOffset);
    // Serialize message field [blood]
    bufferOffset = std_msgs.msg.Float64.serialize(obj.blood, buffer, bufferOffset);
    // Serialize message field [bullet]
    bufferOffset = std_msgs.msg.Int32.serialize(obj.bullet, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Alive_model
    let len;
    let data = new Alive_model(null);
    // Deserialize message field [name]
    data.name = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    // Deserialize message field [blood]
    data.blood = std_msgs.msg.Float64.deserialize(buffer, bufferOffset);
    // Deserialize message field [bullet]
    data.bullet = std_msgs.msg.Int32.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.String.getMessageSize(object.name);
    return length + 12;
  }

  static datatype() {
    // Returns string type for a message object
    return 'judge_system_msgs/Alive_model';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b7a21db24ef5f749eb1636f45852b016';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/String name
    std_msgs/Float64 blood
    std_msgs/Int32 bullet
    ================================================================================
    MSG: std_msgs/String
    string data
    
    ================================================================================
    MSG: std_msgs/Float64
    float64 data
    ================================================================================
    MSG: std_msgs/Int32
    int32 data
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Alive_model(null);
    if (msg.name !== undefined) {
      resolved.name = std_msgs.msg.String.Resolve(msg.name)
    }
    else {
      resolved.name = new std_msgs.msg.String()
    }

    if (msg.blood !== undefined) {
      resolved.blood = std_msgs.msg.Float64.Resolve(msg.blood)
    }
    else {
      resolved.blood = new std_msgs.msg.Float64()
    }

    if (msg.bullet !== undefined) {
      resolved.bullet = std_msgs.msg.Int32.Resolve(msg.bullet)
    }
    else {
      resolved.bullet = new std_msgs.msg.Int32()
    }

    return resolved;
    }
};

module.exports = Alive_model;
