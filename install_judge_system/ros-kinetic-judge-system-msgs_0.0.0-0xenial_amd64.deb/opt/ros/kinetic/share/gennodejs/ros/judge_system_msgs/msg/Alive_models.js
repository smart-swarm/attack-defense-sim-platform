// Auto-generated. Do not edit!

// (in-package judge_system_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Alive_model = require('./Alive_model.js');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class Alive_models {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.team = null;
      this.body = null;
    }
    else {
      if (initObj.hasOwnProperty('team')) {
        this.team = initObj.team
      }
      else {
        this.team = new std_msgs.msg.String();
      }
      if (initObj.hasOwnProperty('body')) {
        this.body = initObj.body
      }
      else {
        this.body = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Alive_models
    // Serialize message field [team]
    bufferOffset = std_msgs.msg.String.serialize(obj.team, buffer, bufferOffset);
    // Serialize message field [body]
    // Serialize the length for message field [body]
    bufferOffset = _serializer.uint32(obj.body.length, buffer, bufferOffset);
    obj.body.forEach((val) => {
      bufferOffset = Alive_model.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Alive_models
    let len;
    let data = new Alive_models(null);
    // Deserialize message field [team]
    data.team = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    // Deserialize message field [body]
    // Deserialize array length for message field [body]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.body = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.body[i] = Alive_model.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.String.getMessageSize(object.team);
    object.body.forEach((val) => {
      length += Alive_model.getMessageSize(val);
    });
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'judge_system_msgs/Alive_models';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '0f9cfcceb304e83ae581ffd7abd4c3c8';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/String team
    Alive_model[] body
    ================================================================================
    MSG: std_msgs/String
    string data
    
    ================================================================================
    MSG: judge_system_msgs/Alive_model
    std_msgs/String name
    std_msgs/Float64 blood
    std_msgs/Int32 bullet
    ================================================================================
    MSG: std_msgs/Float64
    float64 data
    ================================================================================
    MSG: std_msgs/Int32
    int32 data
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Alive_models(null);
    if (msg.team !== undefined) {
      resolved.team = std_msgs.msg.String.Resolve(msg.team)
    }
    else {
      resolved.team = new std_msgs.msg.String()
    }

    if (msg.body !== undefined) {
      resolved.body = new Array(msg.body.length);
      for (let i = 0; i < resolved.body.length; ++i) {
        resolved.body[i] = Alive_model.Resolve(msg.body[i]);
      }
    }
    else {
      resolved.body = []
    }

    return resolved;
    }
};

module.exports = Alive_models;
