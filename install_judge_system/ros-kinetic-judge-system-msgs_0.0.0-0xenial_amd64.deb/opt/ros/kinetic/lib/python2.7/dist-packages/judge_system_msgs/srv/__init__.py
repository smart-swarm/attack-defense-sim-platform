from ._clear_bullets import *
